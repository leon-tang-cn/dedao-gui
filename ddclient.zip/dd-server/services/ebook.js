const express = require('express');
const axios = require('axios');
const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const { createDecipheriv } = require('node:crypto');
const { Buffer } = require('node:buffer');
const { Svg2Html } = require('./svg2html');
const { Svg2Pdf } = require('./svg2pdf');
const { Svg2Epub } = require('./svg2epub');

(async () => {
  var CipherKey = "3e4r06tjkpjcevlbslr3d96gdb5ahbmo" //"3e4r06tjkpjcevlbslr3d96gdb5ahbmo"
  var AesIv = "6fd89a1b3a7f48fb" //"6fd89a1b3a7f48fb"

  async function connectDb() {
    try {
      return await open({
        filename: 'ddinfo.db',
        driver: sqlite3.Database
      });
    } catch (error) {
      console.error('无法连接到数据库:', error);
      return null;
    }
  }

  const ebookService = express.Router();

  ebookService.get('/getEbookList', async (req, res) => {
    const { pageSize, currentPage } = req.query;
    const db = await connectDb();
    try {
      if (!db) {
        res.status(500).send({ message: '无法连接到数据库' });
      }

      let result = await db.get(`SELECT * FROM login_info`);
      if (!result || !result.oauthToken) {
        return res.json({ data: { status: 0 } });
      }

      const ebookListRes = await axios('https://www.dedao.cn/api/hades/v2/product/list', {
        method: 'POST',
        headers: {
          'Accept': 'application/json, text/plain, */*',
          "xi-csrf-token": result.csrfToken,
          'Cookie': result.cookies
        },
        data: {
          "category": "ebook",
          "display_group": true,
          "filter": "all",
          "filter_complete": 0,
          "group_id": 0,
          "order": "study",
          "page": Number(currentPage),
          "page_size": Number(pageSize),
          "sort_type": "desc"
        }
      })
      return res.json(ebookListRes.data);
    } catch (error) {
      if (error.status === 401 || error.status === 403) {
        return res.json({ error: 403, message: '令牌已过期，请重新登录' });
      }
      return res.json({ error: -2, message: error.statusText });
    } finally {
      await db.close()
    }
  });

  const decryptAes = (contents) => {
    const algorithm = 'aes-256-cbc';
    const key = Buffer.from(CipherKey);
    const iv = Buffer.from(AesIv);
    const decipher = createDecipheriv(algorithm, key, iv);
    const ciphertext = Buffer.from(contents, 'base64');

    let decrypted = decipher.update(ciphertext, 'binary', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted
  }

  const getEbookPages = async (chapterId, count, index, offset, readToken, csrfToken, cookies) => {

    try {
      let svgContents = []
      const ebookPages = await axios('https://www.dedao.cn/ebk_web_go/v2/get_pages', {
        method: 'POST',
        headers: {
          'Accept': 'application/json, text/plain, */*',
          "xi-csrf-token": csrfToken,
          'Cookie': cookies
        },
        data: {
          "chapter_id": chapterId,
          "config": {
            "density": 1,
            "direction": 0,
            "font_name": "yahei",
            "font_scale": 1,
            "font_size": 16,
            "height": 200000,
            "line_height": "2em",
            "margin_bottom": 60,
            "margin_left": 30,
            "margin_right": 30,
            "margin_top": 60,
            "paragraph_space": "1em",
            "platform": 1,
            "width": 60000
          },
          "count": count,
          "index": index,
          "offset": offset,
          "orientation": 0,
          "token": readToken
        }
      })

      for (let i = 0; i < ebookPages.data.c.pages.length; i++) {
        const svContent = decryptAes(ebookPages.data.c.pages[i].svg)
        svgContents.push(svContent);
      }
      if (ebookPages.data.c.is_end) {
        return svgContents;
      } else {
        const newIndex = count;
        const newCount = count + 20;
        const nextSvgContents = await getEbookPages(chapterId, newCount, newIndex, offset, readToken, csrfToken, cookies)
        svgContents = svgContents.concat(nextSvgContents)
        return svgContents;
      }
    } catch (error) {
      if (error.status === 401 || error.status === 403) {
        console.log('令牌已过期，请重新登录');
      }
      return []
    }
  }

  ebookService.get('/getEbookDetail', async (req, res) => {
    const { id, enid, title, author, eType } = req.query;
    let downloadType = ['html', 'pdf', 'epub']
    if (eType) {
      downloadType = JSON.parse(eType)
    }
    // 设置响应头以支持 SSE
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const db = await connectDb();
    try {
      if (!db) {
        res.status(500).send({ message: '无法连接到数据库' });
      }

      let configInfo = await db.get(`SELECT * FROM output_config`);
      let outputDir = `${__dirname}/output`;
      if (configInfo && configInfo.output_dir) {
        outputDir = configInfo.output_dir;
      }

      let result = await db.get(`SELECT * FROM login_info`);
      if (!result || !result.oauthToken) {
        return res.json({ data: { status: 0 } });
      }
      res.write(`data: ${JSON.stringify({ processStep: '获取令牌' })}\n\n`);

      const readTokenRes = await axios(`https://www.dedao.cn/api/pc/ebook2/v1/pc/read/token?id=${enid}`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json, text/plain, */*',
          "xi-csrf-token": result.csrfToken,
          'Cookie': result.cookies
        }
      })
      if (readTokenRes.status !== 200) {
        return res.json({ error: -1, message: '查询失败，请稍后重试' });
      }
      const readToken = readTokenRes.data.c.token;

      res.write(`data: ${JSON.stringify({ processStep: '获取图书章节' })}\n\n`);
      const bookDetailInfoRes = await axios(`https://www.dedao.cn/ebk_web/v1/get_book_info?token=${readToken}`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json, text/plain, */*',
          "xi-csrf-token": result.csrfToken,
          'Cookie': result.cookies
        }
      })
      if (bookDetailInfoRes.status !== 200) {
        return res.json({ error: -1, message: bookDetailInfoRes.statusText });
      }

      const orders = bookDetailInfoRes.data.c.bookInfo.orders;
      const toc = bookDetailInfoRes.data.c.bookInfo.toc;

      const index = 0;
      const count = 6;
      const offset = 0;
      let svgContents = [];
      console.time('html Generation Time');
      res.write(`data: ${JSON.stringify({ processStep: '转换图书数据', steps: orders.length })}\n\n`);
      for (var i = 0; i < orders.length; i++) {
        const pageSvgContents = await getEbookPages(orders[i].chapterId, count, index, offset, readToken, result.csrfToken, result.cookies)

        svgContents.push({
          Contents: pageSvgContents,
          ChapterID: orders[i].chapterId,
          PathInEpub: orders[i].PathInEpub,
          OrderIndex: i,
        })
        let currentToc = toc.filter(toc => toc.href.split('#')[0] === orders[i].chapterId)[0];
        if (currentToc && currentToc.text) {
          res.write(`data: ${JSON.stringify({ processKey: currentToc.text })}\n\n`);
        }
      }

      console.timeEnd('html Generation Time');
      const outputFileName = `${id}_${title}_${author}`;

      if (downloadType.findIndex(item => item === 'html') > -1) {
        res.write(`data: ${JSON.stringify({ processStep: '生成HTML文件' })}\n\n`);
        Svg2Html(outputDir, outputFileName, svgContents, toc);
      }

      if (downloadType.findIndex(item => item === 'pdf') > -1) {
        console.time('PDF Generation Time');
        res.write(`data: ${JSON.stringify({ processStep: '生成PDF文件' })}\n\n`);
        await Svg2Pdf(outputDir, outputFileName, title, svgContents, toc);
        console.timeEnd('PDF Generation Time');
      }

      if (downloadType.findIndex(item => item === 'epub') > -1) {
        console.time('EPUB Generation Time');
        res.write(`data: ${JSON.stringify({ processStep: '生成EPUB文件' })}\n\n`);
        await Svg2Epub(outputDir, outputFileName, title, author, svgContents, { toc: toc });
        console.timeEnd('EPUB Generation Time');
      }

      res.write(`data: ${JSON.stringify({ finalResult: "完成" })}\n\n`);
    } catch (error) {
      if (error.status === 401 || error.status === 403) {
        res.write(`data: ${JSON.stringify({ error: 403 })}\n\n`);
      } else {
        res.write(`data: ${JSON.stringify({ error: error })}\n\n`);
      }
    } finally {
      await db.close()
      res.end();
    }
  });

  module.exports = ebookService;
})();