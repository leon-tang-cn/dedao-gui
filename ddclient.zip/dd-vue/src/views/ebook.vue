<template>
  <div class="container">
    <div class="container-header">
      <div style="display: flex;flex-flow: row nowrap;gap: 40px;align-items: center;">
        <el-button type="primary" @click="getEbookList">获取书架清单</el-button>
        <template v-if="multiSelected && multiSelected.length > 0">
          <el-checkbox-group v-model="selectedTypes">
            <template v-for="item in selectTypeOptions" :key="item.value">
              <el-checkbox :value="item.value">{{ item.label }}</el-checkbox>
            </template>
          </el-checkbox-group>
          <el-button size="small" @click="multiDownloadFile">
            批量下载
          </el-button>
        </template>
      </div>
      <div v-if="multiDownloadProgress > 0">
        <el-progress :percentage="multiDownloadProgress" :format="multiDownloadProgressStatus" style="width: 100%;" />
      </div>
      <div v-if="progress > 0">
        <el-progress :percentage="progress" :format="processStatus" style="width: 100%;" />
      </div>
    </div>
    <el-table :data="ebookList" style="width: 100%;flex: 1;" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" />
      <el-table-column type="index" label="#" width="60" align="center" />
      <el-table-column label="书名" width="400">
        <template #default="scope">
          <div style="display: flex; align-items: center;gap: 10px;flex-flow: row nowrap;">
            <img :src="scope.row.icon" alt="icon" style="width: 30px; height: 30px;" />
            <el-tooltip effect="light">
              <template #content>
                <div style="width: 400px;">{{ scope.row.intro }}</div>
              </template>
              <el-link>{{ scope.row.title }}</el-link>
            </el-tooltip>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="author" label="作者" min-width="200" />
      <el-table-column fixed="right" label="操作" min-width="120">
        <template #default="scope">
          <el-button size="small" @click="singleDownloadFile(scope.$index, scope.row, ['pdf', 'epub'])">
            PDF, EPUB
            <el-icon>
              <Download />
            </el-icon>
          </el-button>
          <el-button size="small" @click="singleDownloadFile(scope.$index, scope.row, ['pdf'])">
            PDF
            <el-icon>
              <Download />
            </el-icon>
          </el-button>
          <el-button size="small" @click="singleDownloadFile(scope.$index, scope.row, ['epub'])">
            EPUB
            <el-icon>
              <Download />
            </el-icon>
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <div style="display: flex;flex-flow: row nowrap;justify-content: flex-end;">
      <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize"
        layout="total, prev, pager, next, jumper, default" :total="totalCount" @size-change="handleSizeChange"
        @current-change="handleCurrentChange" />
    </div>
    <div class="container-footer"></div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { sendRequest } from '@/utils/request.js';
import { ElMessage } from 'element-plus';
import { useRouter } from 'vue-router';

const router = useRouter();
const host = import.meta.env.VITE_APP_HOST;

const ebookList = ref([]);
const selectedTypes = ref([]);
const progress = ref(0);
const multiDownloadProgress = ref(0);
const currentStepText = ref('');
const currentRowText = ref('');
const selectTypeOptions = ref([
  { value: 'pdf', label: 'PDF' },
  { value: 'epub', label: 'EPUB' },
])
const currentPage = ref(1);
const pageSize = ref(10);
const totalCount = ref(0);
const multiSelected = ref([]);

const handleSizeChange = (val) => {
  pageSize.value = val;
  getEbookList();
}
const handleCurrentChange = (val) => {
  currentPage.value = val;
  getEbookList();
}
const processStatus = () => {
  return `${currentStepText.value}`;
};
const multiDownloadProgressStatus = () => {
  return `${currentRowText.value}`;
};

const handleSelectionChange = (val) => {
  multiSelected.value = val;
}

selectedTypes.value = ['pdf', 'epub']

const getEbookList = async () => {
  const res = await sendRequest(`/api/ebook/getEbookList?currentPage=${currentPage.value}&pageSize=${pageSize.value}`)

  if (res.error) {
    ElMessage.error(res.message);
    if (res.error === 403) {
      router.push({ name: 'home' });
      return; 
    }
    ebookList.value = [];
    return;
  }
  ebookList.value = res.c?.list || [];
  totalCount.value = res.c?.total || 0;
}

const checkConfig = async () => {
  const res = await sendRequest('/api/config/getConfig')
  if (!res.output_dir) {
    ElMessage.error("请先配置输出目录！");
    router.push({ name: 'config' });
  }
}

const multiDownloadFile = async () => {
  await checkConfig();
  const step = Math.floor(100 / multiSelected.value.length);
  for (let i = 0; i < multiSelected.value.length; i++) {
    const row = multiSelected.value[i];
    multiDownloadProgress.value += 1;
    currentRowText.value = `正在下载第${i + 1}本: ${row.title}`;
    await downloadFile(i, row);
    multiDownloadProgress.value += (step - 1);
  }
  multiDownloadProgress.value = 100;
  setTimeout(() => {
    multiDownloadProgress.value = 0;
  }, 3000);
}

const singleDownloadFile = async (index, row, types) => {
  await checkConfig();
  await downloadFile(index, row, types);
}

const downloadFile = async (index, row, types) => {
  return new Promise((resolve, reject) => {
    let fetchTypes = [];
    if (types && types.length > 0) {
      fetchTypes = types;
    } else {
      fetchTypes = selectedTypes.value;
    }
    progress.value = 0;
    currentStepText.value = ''
    const eventSource = new EventSource(`${host}/api/ebook/getEbookDetail?id=${row.id}&enid=${row.enid}&title=${row.title}&author=${row.author}&eType=${JSON.stringify(fetchTypes)}`);

    const totalSteps = 3 + fetchTypes.length + 1;
    const step = 10;
    let pageStep = 0;

    eventSource.onmessage = async (event) => {
      const data = JSON.parse(event.data);
      if (data.processStep) {
        progress.value += step;
        currentStepText.value = `${data.processStep}`
      }
      if (data.steps) {
        pageStep = Math.floor((100 - (10 * totalSteps)) / data.steps);
      }
      if (data.processKey && pageStep > 0) {
        progress.value += pageStep;
        currentStepText.value = `${data.processKey}`
      }
      if (data.finalResult) {
        progress.value = 100;
        currentStepText.value = data.finalResult
        eventSource.close();
        resolve();
        setTimeout(() => {
          progress.value = 0;
          currentStepText.value = ''
        }, 3000);
      }
      if (data.error) {
        currentStepText.value = data.error
        eventSource.close();
        reject(data.error);
      }
    };

    eventSource.onerror = (error) => {
      currentStepText.value = '发生错误'
      eventSource.close();
      reject(error);
    };
  });
}

</script>

<style scoped>
.container {
  text-align: center;
  padding: 20px;
  overflow: auto;
  height: 100%;
  display: flex;
  flex-flow: column nowrap;
  gap: 10px;
}

.container-header {
  display: flex;
  flex-flow: column nowrap;
}

.container-footer {
  height: 20px;
}
</style>