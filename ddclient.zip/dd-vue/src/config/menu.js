export function getMenus() {
  const menus = [
    {
      id: 1,
      name: "home",
      path: "/",
      meta: {
        menuName: "首页",
        icon: "HomeFilled"
      }
    },
    {
      id: 2,
      name: "ebook",
      path: "/ebook",
      meta: {
        menuName: "电子书",
        icon: "models"
      }
    },
    {
      id: 3,
      name: "config",
      path: "/config",
      meta: {
        menuName: "配置",
        icon: "setting"
      }
    }
  ]
  return menus;
}